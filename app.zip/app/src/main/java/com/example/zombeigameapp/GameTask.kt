//GameTask
package com.example.zombeigameapp

interface GameTask {
    fun closeGame(score: Int)
    fun startNewGame()
}
